
New animals must have the naming format to be usable:
<Animal enum value>.png         # General animals
<Animal enum value>_cave.png    # Variant for CaveTile

===============================
CREDIT
All art work created by: Shen Jiang with icons from the Microsoft Suite