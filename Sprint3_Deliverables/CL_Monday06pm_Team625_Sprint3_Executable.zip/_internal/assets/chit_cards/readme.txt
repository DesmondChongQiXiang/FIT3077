
For new chit card pictures to be usable, please ensure the following name format is followed:
chit_card_<Animal enum value>_<symbol count>.png

===============================
CREDIT
All art work created by: Shen Jiang with icons from the Microsoft Suite