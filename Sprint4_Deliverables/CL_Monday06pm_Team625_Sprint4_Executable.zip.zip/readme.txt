Target Platform: Windows 11

How to run the executable:
1. Extract all the files in this zip into a separate folder
2. Run the executable called ‘main’ located in the folder you just extracted to
