
For new cave tile variants to be usable, please ensure the following name format is followed:
cave_tile_<CaveTileVariant enum value>.png

===============================
CREDIT
All art work created by: Shen Jiang with icons from the Microsoft Suite