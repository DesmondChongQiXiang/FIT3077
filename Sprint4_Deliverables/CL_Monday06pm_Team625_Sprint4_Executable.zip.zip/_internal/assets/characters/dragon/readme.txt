
New dragon variants must conform to the following naming format:
dragon_<PlayableCharacterVariant enum value>.png

====================
CREDITS:
All spirtes made by: Shen Jiang using icons from Microsoft Suite